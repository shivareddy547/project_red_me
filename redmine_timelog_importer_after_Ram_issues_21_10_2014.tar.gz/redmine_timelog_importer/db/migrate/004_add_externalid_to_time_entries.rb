class AddExternalidToTimeEntries < ActiveRecord::Migration
  # model removed
  def self.up
    add_column :time_entries, :external_id, :integer
  end

  def self.down
    remove_column :time_entries, :external_id
  end
end
